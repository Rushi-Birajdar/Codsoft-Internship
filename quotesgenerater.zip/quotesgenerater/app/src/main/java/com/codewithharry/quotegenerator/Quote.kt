package com.codewithharry.quotegenerator


data class Quote(val text: String, val author: String )