# CODSOFT
It's my first basic quote generator app.Any suuggestion are welcomed. Enjoy 
